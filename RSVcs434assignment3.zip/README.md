# How To Use

Open CS434 ssh in Putty

Open Bash

cd /

source /scratch/cs434spring2018/env_3.5_pytorch/bin/activate\

cd /nfs/stak/users/USERNAME


To Run:
python FILENAME.py

# cs434ass3
Machine Learning and Data Mining Russell, Sherburne, Volkman

